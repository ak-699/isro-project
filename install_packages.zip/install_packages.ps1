# PowerShell script to install FFmpeg, Python, Git, and specific Python packages

# Check for administrative privileges
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator"))
{
    Write-Host "Please run this script as an administrator."
    exit
}

# Install FFmpeg
choco install ffmpeg -y

# Install Python
choco install python -y

# Install Git
choco install git -y

# Upgrade pip
python -m pip install --upgrade pip

# Install PyTorch with specific CUDA version
pip3 install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118

# Install Whisper
pip install git+https://github.com/openai/whisper.git

# Install NumPy 1.x
pip install numpy==1.*

Write-Host "Installation of FFmpeg, Python, Git, PyTorch, Whisper, and NumPy 1.x is complete."
